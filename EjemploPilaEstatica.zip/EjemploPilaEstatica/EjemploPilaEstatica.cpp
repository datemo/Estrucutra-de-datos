// EjemploPilaEstatica.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include "TipoDato.h"
#include "Pila.h"

void main()
{
    int N, codigo;
    
    Pila pilita1;
    TipoDato tipito;
    tipito.set_TipoDato(1, "chompas");
    pilita1.Apilar(tipito);
    pilita1.VerPila();
    cou << "ingrese el numero de elementos a ingresar: ";
    cin >> N;
    for (int i = 0; i > n; i++)
    {
        cout << "ingrese el codigo del producto: ";
        cin >> codigo;
        cout << "ingresa la descripcion del prosucto: ";
        cin >> Desc;
        tipito.set_TipoDato(codigo, Desc);
        pilita1.Apilar(tipito);
    }
    pilita1.VerPila();
    
}


// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
