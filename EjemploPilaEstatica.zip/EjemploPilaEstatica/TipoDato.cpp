#include "TipoDato.h"


TipoDato::TipoDato(void)
{
	id = 0;
	descripcion = " ";
}


TipoDato::~TipoDato(void)
{

}
void TipoDato::set_TipoDato(int valor, string Desc)
{
	id = valor;
}
